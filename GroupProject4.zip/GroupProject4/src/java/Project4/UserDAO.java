/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project4;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


public class UserDAO {

    static Connection currentCon = null;
    static ResultSet rs = null;

    public static User login(User bean) throws Exception {
        //preparing some objects for connection
        Statement stmt = null;

        String username = bean.getEmail();
        String password = bean.getPassword();

        String query
                = "select * from user where Email='"
                + username
                + "' AND Password='"
                + password
                + "'";

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Your user name is " + username);
        System.out.println("Your password is " + password);
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.createStatement();
            rs = stmt.executeQuery(query);
            boolean more = rs.next();

            // if user does not exist set the isValid variable to false
            if (!more) {
                System.out.println("Sorry, you are not a registered user! Please sign up first");
                bean = null;
            } //if user exists set the isValid variable to true
            else if (more) {
                String firstName = rs.getString("Name");
                String lastName = rs.getString("LastName");

                System.out.println("Welcome " + firstName);
                bean.setAge(rs.getInt("Age"));
                bean.setEmail(username);
                bean.setHideAge(rs.getInt("HideAge"));
                bean.setHideFriends(rs.getInt("HideFriends"));
                bean.setHideStatus(rs.getInt("HideStatus"));
                bean.setID(rs.getInt("ID"));
                bean.setLastName(lastName);
                bean.setName(firstName);
                bean.setPassword(password);
                bean.setProfilePicturePath(rs.getString("ProfilePicturePath"));
                bean.setStatus(rs.getString("Status"));
            }

        } catch (Exception ex) {
            System.out.println("Unable to login : " + ex);
            throw ex;
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return bean;

    }

    public static User getUser(int id) throws Exception {
        //preparing some objects for connection
        Statement stmt = null;
        User bean = null;
        String query
                = "select * from user where ID=" + id;

        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.createStatement();
            rs = stmt.executeQuery(query);
            boolean more = rs.next();

            // if user does not exist set the isValid variable to false
            if (!more) {
                System.out.println("Sorry, User not available");
                bean = null;
            } //if user exists set the isValid variable to true
            else if (more) {
                bean = new User();
                String firstName = rs.getString("Name");
                String lastName = rs.getString("LastName");
                bean.setAge(rs.getInt("Age"));
                bean.setEmail(rs.getString("Email"));
                bean.setHideAge(rs.getInt("HideAge"));
                bean.setHideFriends(rs.getInt("HideFriends"));
                bean.setHideStatus(rs.getInt("HideStatus"));
                bean.setID(rs.getInt("ID"));
                bean.setLastName(lastName);
                bean.setName(firstName);
                bean.setPassword(rs.getString("Password"));
                bean.setProfilePicturePath(rs.getString("ProfilePicturePath"));
                bean.setStatus(rs.getString("Status"));
            }

        } catch (Exception ex) {
            System.out.println("Error in fetching User : " + ex);
            throw ex;
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return bean;

    }

    public static ArrayList<User> getUsers(String userQuery) throws Exception {
        //preparing some objects for connection
        PreparedStatement stmt = null;
        ArrayList<User> result = new ArrayList<>();
        String query
                = "select * from `user` where `Name` like ? or `LastName` like ? order by `Name` asc";

        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);
            stmt.setObject(1, userQuery + "%");
            stmt.setObject(2, userQuery + "%");
            rs = stmt.executeQuery();
            while (rs.next()) {
                User bean = new User();
                String firstName = rs.getString("Name");
                String lastName = rs.getString("LastName");
                bean.setAge(rs.getInt("Age"));
                bean.setEmail(rs.getString("Email"));
                bean.setHideAge(rs.getInt("HideAge"));
                bean.setHideFriends(rs.getInt("HideFriends"));
                bean.setHideStatus(rs.getInt("HideStatus"));
                bean.setID(rs.getInt("ID"));
                bean.setLastName(lastName);
                bean.setName(firstName);
                bean.setPassword(rs.getString("Password"));
                bean.setProfilePicturePath(rs.getString("ProfilePicturePath"));
                bean.setStatus(rs.getString("Status"));
                result.add(bean);
            }

        } catch (Exception ex) {
            System.out.println("Error in fetching User : " + ex);
            throw ex;
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return result;

    }

    public static boolean register(User bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        String username = bean.getEmail();
        String password = bean.getPassword();

        String query = "";
        query = "insert into `user` (`Name`,`LastName`,"
                + "`Email`,"
                + "`Password`,"
                + "`Age`,"
                + "`Status`,"
                + "`ProfilePicturePath`,"
                + "`HideAge`,"
                + "`HideFriends`,"
                + "`HideStatus`"
                + ") values(?,?,?,?,?,?,?,?,?,?)";

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Your user name is " + username);
        System.out.println("Your password is " + password);
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);

            stmt.setObject(1, bean.getName());
            stmt.setObject(2, bean.getLastName());
            stmt.setObject(3, bean.getEmail());
            stmt.setObject(4, bean.getPassword());
            stmt.setObject(5, bean.getAge());
            stmt.setObject(6, bean.getStatus() == null ? "" : bean.getStatus());
            stmt.setObject(7, bean.getProfilePicturePath() == null ? "" : bean.getProfilePicturePath());
            stmt.setObject(8, bean.getHideAge());
            stmt.setObject(9, bean.getHideFriends());
            stmt.setObject(10, bean.getHideStatus());
            stmt.executeUpdate();
            query = "Syntax : " + query;
            query += " <BR> Query : " + stmt.toString().substring(stmt.toString().indexOf("insert"));
            System.out.println(query);
            res = true;

        } catch (Exception ex) {
            System.out.println("Error in fetching Friends : " + ex);
            throw new Exception(ex.getMessage() + "<BR>" + query);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean update(User bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        String username = bean.getEmail();
        String password = bean.getPassword();

        String query = "";
        query = "update `user` set `Name`=? ,`LastName`= ?,"
                + "`Email` = ?,"
                + "`Password` = ?,"
                + "`Age` = ?,"
                + "`Status` = ?,"
                + "`ProfilePicturePath` = ?,"
                + "`HideAge` = ?,"
                + "`HideFriends` = ?,"
                + "`HideStatus` = ?"
                + " where ID=?";

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Your user name is " + username);
        System.out.println("Your password is " + password);
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);

            stmt.setObject(1, bean.getName());
            stmt.setObject(2, bean.getLastName());
            stmt.setObject(3, bean.getEmail());
            stmt.setObject(4, bean.getPassword());
            stmt.setObject(5, bean.getAge());
            stmt.setObject(6, bean.getStatus());
            stmt.setObject(7, bean.getProfilePicturePath());
            stmt.setObject(8, bean.getHideAge());
            stmt.setObject(9, bean.getHideFriends());
            stmt.setObject(10, bean.getHideStatus());
            stmt.setObject(11, bean.getID());
            query = "Syntax : " + query;
            query += " <BR> Query : " + stmt.toString().substring(stmt.toString().indexOf("update"));
            System.out.println(query);
            stmt.executeUpdate();
            res = true;

        } catch (Exception ex) {
            System.out.println("Error in updating user : " + ex);
            throw new Exception(ex.getMessage() + "<BR>" + query);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean updateName(User bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        String query = "";
        query = "update `user` set `Name`=?"
                + " where ID=?";
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);

            stmt.setObject(1, bean.getName());
            stmt.setObject(2, bean.getID());
            query = "Syntax : " + query;
            query += " <BR> Query : " + stmt.toString().substring(stmt.toString().indexOf("update"));
            System.out.println(query);
            stmt.executeUpdate();
            res = true;

        } catch (Exception ex) {
            System.out.println("Error in updating User : " + ex);
            throw new Exception(ex.getMessage() + "<BR>" + query);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean updateLastName(User bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        String query = "";
        query = "update `user` set `LastName`=?"
                + " where ID=?";
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);

            stmt.setObject(1, bean.getLastName());
            stmt.setObject(2, bean.getID());
            query = "Syntax : " + query;
            query += " <BR> Query : " + stmt.toString().substring(stmt.toString().indexOf("update"));
            System.out.println(query);
            stmt.executeUpdate();
            res = true;

        } catch (Exception ex) {
            System.out.println("Error in updating User : " + ex);
            throw new Exception(ex.getMessage() + "<BR>" + query);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean updateAge(User bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        String query = "";
        query = "update `user` set `Age`=?"
                + " where ID=?";
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);

            stmt.setObject(1, bean.getAge());
            stmt.setObject(2, bean.getID());
            query = "Syntax : " + query;
            query += " <BR> Query : " + stmt.toString().substring(stmt.toString().indexOf("update"));
            System.out.println(query);
            stmt.executeUpdate();
            res = true;

        } catch (Exception ex) {
            System.out.println("Error in updating User : " + ex);
            throw new Exception(ex.getMessage() + "<BR>" + query);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean updateStatus(User bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        String query = "";
        query = "update `user` set `Status`=?"
                + " where ID=?";
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);

            stmt.setObject(1, bean.getStatus());
            stmt.setObject(2, bean.getID());
            query = "Syntax : " + query;
            query += " <BR> Query : " + stmt.toString().substring(stmt.toString().indexOf("update"));
            System.out.println(query);
            stmt.executeUpdate();
            res = true;

        } catch (Exception ex) {
            System.out.println("Error in updating User : " + ex);
            throw new Exception(ex.getMessage() + "<BR>" + query);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean updateHideAge(User bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        String query = "";
        query = "update `user` set `HideAge`=?"
                + " where ID=?";
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);

            stmt.setObject(1, bean.getHideAge());
            stmt.setObject(2, bean.getID());
            query = "Syntax : " + query;
            query += " <BR> Query : " + stmt.toString().substring(stmt.toString().indexOf("update"));
            System.out.println(query);
            stmt.executeUpdate();
            res = true;

        } catch (Exception ex) {
            System.out.println("Error in updating User : " + ex);
            throw new Exception(ex.getMessage() + "<BR>" + query);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean updateHideStatus(User bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        String query = "";
        query = "update `user` set `HideStatus`=?"
                + " where ID=?";
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);

            stmt.setObject(1, bean.getHideStatus());
            stmt.setObject(2, bean.getID());
            query = "Syntax : " + query;
            query += " <BR> Query : " + stmt.toString().substring(stmt.toString().indexOf("update"));
            System.out.println(query);
            stmt.executeUpdate();
            res = true;

        } catch (Exception ex) {
            System.out.println("Error in updating User : " + ex);
            throw new Exception(ex.getMessage() + "<BR>" + query);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean updateHideFriends(User bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        String query = "";
        query = "update `user` set `HideFriends`=?"
                + " where ID=?";
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);

            stmt.setObject(1, bean.getHideFriends());
            stmt.setObject(2, bean.getID());
            query = "Syntax : " + query;
            query += " <BR> Query : " + stmt.toString().substring(stmt.toString().indexOf("update"));
            System.out.println(query);
            stmt.executeUpdate();
            res = true;

        } catch (Exception ex) {
            System.out.println("Error in updating User : " + ex);
            throw new Exception(ex.getMessage() + "<BR>" + query);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }
}

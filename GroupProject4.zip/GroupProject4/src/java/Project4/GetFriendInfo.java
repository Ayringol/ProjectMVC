
package Project4;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetFriendInfo extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            int userID = Integer.parseInt(request.getParameter("userID").replace("FriendID-", ""));
            try {
                User user = new User();
                user = UserDAO.getUser(userID);

                out.println("<div>"
                        + "<span style=\"color: #4C73BE\" >Name:</span>&nbsp;&nbsp;&nbsp;&nbsp;"
                        + "<span id=\"friendName\" style=\"color: #4C73BE; font-weight: bold\" >" + user.getName() + "</span>"
                        + "</div>"
                        + "<div>"
                        + "<span style=\"color: #4C73BE\" >Last Name:</span>&nbsp;&nbsp;&nbsp;&nbsp;"
                        + "<span id=\"friendLastName\" style=\"color: #4C73BE; font-weight: bold\" >" + user.getLastName() + "</span>"
                        + "</div>"
                        + "<div>"
                        + "<span style=\"color: #4C73BE\" >Age:</span>&nbsp;&nbsp;&nbsp;&nbsp;"
                        + "<span id=\"friendAge\" style=\"color: #4C73BE; font-weight: bold\" >" + (user.getHideAge() == 0 ? user.getAge() : "N/A") + "</span>"
                        + "</div>"
                        + "<div>"
                        + "<span style=\"color: #4C73BE\" >Status:</span>&nbsp;&nbsp;&nbsp;&nbsp;"
                        + "<span id=\"friendStatus\" style=\"color: #4C73BE; font-weight: bold\" >" + (user.getHideStatus() == 0 ? user.getStatus() : "N/A") + "</span>"
                        + "</div>");

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

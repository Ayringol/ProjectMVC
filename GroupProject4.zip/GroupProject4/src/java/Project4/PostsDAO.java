/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project4;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


public class PostsDAO {

    static Connection currentCon = null;
    static ResultSet rs = null;

    public static ArrayList<Posts> getPosts(Posts bean) throws Exception {
        ArrayList<Posts> postsList = null;
        //preparing some objects for connection
        Statement stmt = null;

        int user_id = bean.getUserID();

        String query
                = "select * from posts where UserID="
                + user_id + " order by PostedAt desc";

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.createStatement();
            rs = stmt.executeQuery(query);

            // if user does not exist set the isValid variable to false
            postsList = new ArrayList<>();
            while (rs.next()) {
                Posts post = new Posts();
                post.setPostedAt(rs.getTimestamp("PostedAt"));
                post.setStatus(rs.getString("Status"));
                post.setID(rs.getInt("ID"));
                post.setUserID(rs.getInt("UserID"));
                postsList.add(post);
            }
        } catch (Exception ex) {
            System.out.println("Error in fetching Posts : " + ex);
            throw ex;
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return postsList;

    }

    public static boolean deletePost(Posts bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        Statement stmt = null;

        int id = bean.getID();
        String query
                = "delete from posts where ID="
                + id;

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.createStatement();
            stmt.executeUpdate(query);
            res = true;
        } catch (Exception ex) {
            System.out.println("Error in deleting Posts : " + ex);
            throw ex;
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean addPost(Posts bean) {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        int userid = bean.getUserID();
        String post = bean.getStatus();
        String query
                = "insert into posts (UserID,Status) values(?,?)";

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);
            stmt.setObject(1, userid);
            stmt.setObject(2, post);
            stmt.execute();
            res = true;
        } catch (Exception ex) {
            System.out.println("Error in adding post : " + ex);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean editPost(Posts bean) throws Exception {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        int userid = bean.getUserID();
        int id = bean.getID();
        String post = bean.getStatus();
        String query
                = "update posts set UserID=? ,Status= ? where ID=?";

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);
            stmt.setObject(1, userid);
            stmt.setObject(2, post);
            stmt.setObject(2, id);
            stmt.executeUpdate();
            res = true;
        } catch (Exception ex) {
            System.out.println("Error in adding post : " + ex);
            throw ex;
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }
}

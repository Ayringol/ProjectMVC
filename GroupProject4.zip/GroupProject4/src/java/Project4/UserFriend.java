/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project4;

public class UserFriend {

    private int ID;
    private String name, LastName;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    @Override
    public String toString() {
        return "<a href=\"\" style=\"color: #3F8C27;\" data-toggle=\"modal\" class=\"myfriends\"data-target=\"#friendProfile\" id=\"FriendID-" + ID + "\">" + name + " " + LastName + "</a><br>";
    }

}

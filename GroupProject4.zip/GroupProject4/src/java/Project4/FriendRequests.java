/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project4;

import java.sql.Timestamp;

public class FriendRequests {

    private int ID, SentToID, SentFromID;
    private Timestamp SentTime;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getSentToID() {
        return SentToID;
    }

    public void setSentToID(int SentToID) {
        this.SentToID = SentToID;
    }

    public int getSentFromID() {
        return SentFromID;
    }

    public void setSentFromID(int SentFromID) {
        this.SentFromID = SentFromID;
    }

    public Timestamp getSentTime() {
        return SentTime;
    }

    public void setSentTime(Timestamp SentTime) {
        this.SentTime = SentTime;
    }

}

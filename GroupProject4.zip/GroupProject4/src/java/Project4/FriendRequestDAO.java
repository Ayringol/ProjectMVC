/*
 * To add a friend and automaticle add to requested friend list
 */
package Project4;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class FriendRequestDAO {

    static Connection currentCon = null;
    static ResultSet rs = null;

    public static ArrayList<FriendRequests> getRequests(FriendRequests bean) {
        ArrayList<FriendRequests> requestsList = null;
        //preparing some objects for connection
        Statement stmt = null;

        int user_id = bean.getSentToID();

        String query
                = "select * from friendrequests where SentToID="
                + user_id;

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.createStatement();
            rs = stmt.executeQuery(query);

            // if user does not exist set the isValid variable to false
            requestsList = new ArrayList<>();
            while (rs.next()) {
                FriendRequests request = new FriendRequests();
                request.setSentTime(rs.getTimestamp("SentTime"));
                request.setID(rs.getInt("ID"));
                request.setSentFromID(rs.getInt("SentFromID"));
                request.setSentToID(rs.getInt("SentToID"));
                requestsList.add(request);
            }
        } catch (Exception ex) {
            System.out.println("Error in fetching Friend Requests : " + ex);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return requestsList;

    }

    public static boolean deleteRequest(FriendRequests bean) {
        boolean res = false;
        //preparing some objects for connection
        Statement stmt = null;

        int id = bean.getID();
        String query
                = "delete from posts where ID="
                + id;

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.createStatement();
            stmt.execute(query);
            res = true;
        } catch (Exception ex) {
            System.out.println("Error in deleting Friend Requests : " + ex);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean sendRequest(FriendRequests bean) {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        int from = bean.getSentFromID();
        int to = bean.getSentToID();
        String query
                = "insert into friendrequests (SentFromID,SentToID) values(?,?)";

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.prepareStatement(query);
            stmt.setObject(1, from);
            stmt.setObject(2, to);
            stmt.execute();
            res = true;
        } catch (Exception ex) {
            System.out.println("Error in sending friend request : " + ex);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean acceptRequest(FriendRequests bean) {
        boolean res = false;
        //preparing some objects for connection
        PreparedStatement stmt = null;

        int from = bean.getSentFromID();
        int to = bean.getSentToID();
        //res = deleteRequest(bean);

        Friends friend = new Friends();
        friend.setFriendID(from);
        friend.setUserID(to);
        res = true;
        if (res) {
            res = FriendsDAO.addFriend(friend);
        }

        friend.setFriendID(to);
        friend.setUserID(from);
        if (res) {
            res = FriendsDAO.addFriend(friend);
        }

        return res;

    }
}

/*
 * Database handler
 */
package Project4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
public class DBHandler {

    private static String path = "jdbc:mysql://localhost:3306/";
    private static String user = "root";
    private static String pass = "1a77ga21"; //db pass
    private static String dbName = "project4db";
    private static String driver = "com.mysql.jdbc.Driver";
    public static Connection con;

    public static Connection getConnection() {
        try {
            if (con == null || con.isClosed()) {
                try {
                    Class.forName(driver);
                    con = DriverManager.getConnection(path + dbName, user, pass);
                } catch (Exception e) {
                    System.out.println("Error in DBHandler : " + e);
                    e.printStackTrace();
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
}

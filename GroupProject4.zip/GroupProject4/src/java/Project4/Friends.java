
package Project4;

import java.sql.Timestamp;

public class Friends {

    private int ID, UserID, FriendID;
    private Timestamp FriendSince;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int UserID) {
        this.UserID = UserID;
    }

    public int getFriendID() {
        return FriendID;
    }

    public void setFriendID(int FriendID) {
        this.FriendID = FriendID;
    }

    public Timestamp getFriendSince() {
        return FriendSince;
    }

    public void setFriendSince(Timestamp FriendSince) {
        this.FriendSince = FriendSince;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project4;

import java.sql.Timestamp;


public class Posts {

    private int ID, UserID;
    private String Status;
    private Timestamp PostedAt;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int UserID) {
        this.UserID = UserID;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        this.Status = status;
    }

    public Timestamp getPostedAt() {
        return PostedAt;
    }

    public void setPostedAt(Timestamp PostedAt) {
        this.PostedAt = PostedAt;
    }

}

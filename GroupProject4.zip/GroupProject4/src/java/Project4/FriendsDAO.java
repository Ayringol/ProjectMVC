
package Project4;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class FriendsDAO {

    static Connection currentCon = null;
    static ResultSet rs = null;

    public static ArrayList<UserFriend> getFriends(Friends bean) {
        ArrayList<UserFriend> friendsList = null;
        //preparing some objects for connection
        Statement stmt = null;

        int user_id = bean.getUserID();

        String query
                = "select f.FriendID,u.Name,u.LastName from friends f left join `user` u on f.FriendID=u.ID where UserID="
                + user_id;

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.createStatement();
            rs = stmt.executeQuery(query);

            // if user does not exist set the isValid variable to false
            friendsList = new ArrayList<>();
            while (rs.next()) {
                UserFriend friend = new UserFriend();
                friend.setLastName(rs.getString("LastName"));
                friend.setName(rs.getString("Name"));
                friend.setID(rs.getInt("FriendID"));
                friendsList.add(friend);
            }
        } catch (Exception ex) {
            System.out.println("Error in fetching Friends : " + ex);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return friendsList;

    }

    public static boolean deleteFriend(Friends bean) {
        boolean res = false;
        //preparing some objects for connection
        Statement stmt = null;

        int id = bean.getID();
        String query
                = "delete from friends where ID="
                + id;

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.createStatement();
            stmt.execute(query);
            res = true;
        } catch (Exception ex) {
            System.out.println("Error in deleting Friends : " + ex);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }

    public static boolean addFriend(Friends bean) {
        boolean res = false;
        //preparing some objects for connection
        Statement stmt = null;

        int userid = bean.getUserID();
        int friend = bean.getFriendID();
        String query
                = "insert into friends(UserID,FriendID) values("
                + userid + "," + friend + ")";

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Query: " + query);

        try {
            //connect to DB
            currentCon = DBHandler.getConnection();
            stmt = currentCon.createStatement();
            stmt.execute(query);
            res = true;
        } catch (Exception ex) {
            System.out.println("Error in adding Friends : " + ex);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return res;

    }
}

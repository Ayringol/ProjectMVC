/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project4;


public class User {

    private int ID, Age, HideAge, HideStatus, HideFriends;
    private String Name, LastName, Email, Password, Status, ProfilePicturePath;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }

    public int getHideAge() {
        return HideAge;
    }

    public void setHideAge(int HideAge) {
        this.HideAge = HideAge;
    }

    public int getHideStatus() {
        return HideStatus;
    }

    public void setHideStatus(int HideStatus) {
        this.HideStatus = HideStatus;
    }

    public int getHideFriends() {
        return HideFriends;
    }

    public void setHideFriends(int HideFriends) {
        this.HideFriends = HideFriends;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getProfilePicturePath() {
        return ProfilePicturePath;
    }

    public void setProfilePicturePath(String ProfilePicturePath) {
        this.ProfilePicturePath = ProfilePicturePath;
    }

}
